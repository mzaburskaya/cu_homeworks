"""Export only coursework fields, with anonymous order keys. Never exports addresses."""
import json,sys,hashlib
from pathlib import Path
import openpyxl
root=Path(__file__).resolve().parent
source=Path(sys.argv[1])
w=openpyxl.load_workbook(source,read_only=True,data_only=True)
rows=w.active.iter_rows(values_only=True); headers=next(rows)
raw=[dict(zip(headers,r)) for r in rows]
orders={}; products={}; data=[]
for r in raw:
 if r['Статус']!='доставлен':continue
 key=str(r['Номер заказа']); orders.setdefault(key,len(orders))
 product=(r['Категория'],r['Название позиции']); products.setdefault(product,len(products))
 assert abs(r['Сумма']-r['Количество товаров']*r['Цена со скидкой'])<.01
 assert abs(r['Скидка']-(r['Цена без скидки']-r['Цена со скидкой']))<.01
 data.append([r['Дата заказа'].strftime('%Y-%m'),orders[key],products[product],r['Количество товаров'],r['Сумма'],r['Скидка']*r['Количество товаров']])
output={'source':'Вариант A. Дом и дача','rows':data,'products':[{'id':i,'category':c,'name':n} for (c,n),i in products.items()],'columns':['month','order','product','units','spend','discountTotal']}
(root/'data.js').write_text('window.ORDER_DATA='+json.dumps(output,ensure_ascii=False,separators=(',',':'))+';',encoding='utf8')
print(json.dumps({'deliveredOrders':len(orders),'deliveredRows':len(data),'products':len(products),'spend':sum(r[4] for r in data),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2))
