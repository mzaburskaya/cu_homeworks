const {createApp,nextTick}=Vue;
const palette=['#387c64','#d39849','#6b8fa5','#ab7693','#829246','#c77158','#6373a5','#69a79c','#ac906e','#8b7baa','#8b9690'];
const allCategories=[...new Set(ORDER_DATA.products.map(p=>p.category))].sort((a,b)=>a.localeCompare(b,'ru'));
const rows=ORDER_DATA.rows.map(([month,order,product,units,spend,discountTotal])=>({month,order,product,units,spend,discountTotal,category:ORDER_DATA.products[product].category}));
const sum=(xs,key)=>d3.sum(xs,x=>x[key]);
function aggregate(xs){const units=sum(xs,'units');return {orders:new Set(xs.map(x=>x.order)).size,units,spend:sum(xs,'spend'),discount:units?sum(xs,'discountTotal')/units:null};}
function shiftMonth(m,delta){const [y,n]=m.split('-').map(Number),d=new Date(Date.UTC(y,n-1+delta,1));return d.toISOString().slice(0,7);}
const format=(n,key)=>n==null?'—':new Intl.NumberFormat('ru-RU',{maximumFractionDigits:key==='discount'?2:0}).format(n);
const monthName=m=>new Intl.DateTimeFormat('ru-RU',{month:'long',year:'numeric',timeZone:'UTC'}).format(new Date(m+'-01')).replace(' г.','');
function smallChart(node,series,key,color,width,height){
 const s=d3.select(node);s.selectAll('*').remove();s.attr('viewBox',`0 0 ${width} ${height}`);
 const margin={left:39,right:16,top:12,bottom:24}, x=d3.scalePoint().domain(series.map(x=>x.month)).range([margin.left,width-margin.right]);
 const values=series.map(v=>v[key]).filter(v=>v!=null), max=d3.max(values)||1;
 const y=d3.scaleLinear().domain([0,max*1.12]).nice(3).range([height-margin.bottom,margin.top]);
 const tickFormat=v=>Math.abs(v)>=1000?format(v/1000,'discount')+'к':format(v,key);
 s.append('g').attr('transform',`translate(${margin.left},0)`).call(d3.axisLeft(y).ticks(3).tickSize(-(width-margin.left-margin.right)).tickFormat(tickFormat)).call(g=>g.select('.domain').remove());
 const ticks=series.filter((_,i)=>i%6===0||i===series.length-1).map(d=>d.month);
 s.append('g').attr('transform',`translate(0,${height-margin.bottom})`).call(d3.axisBottom(x).tickValues(ticks).tickSize(0).tickPadding(9).tickFormat(m=>m.slice(5)+'.'+m.slice(2,4)));
 s.append('path').datum(series).attr('fill','none').attr('stroke',color).attr('stroke-width',2).attr('d',d3.line().defined(d=>d[key]!=null).x(d=>x(d.month)).y(d=>y(d[key])));
 s.selectAll('circle').data(series.filter(d=>d[key]!=null)).join('circle').attr('cx',d=>x(d.month)).attr('cy',d=>y(d[key])).attr('r',2.5).attr('fill',color).append('title').text(d=>`${monthName(d.month)}: ${format(d[key],key)}`);
}
const app=createApp({
 data:()=>({category:'',month:d3.max(rows,x=>x.month),categories:allCategories,months:[...new Set(rows.map(x=>x.month))].sort().slice(23),sortKey:'units',showAll:false,tip:null,metrics:[{key:'orders',title:'Количество заказов',unit:''},{key:'spend',title:'Сумма трат',unit:'₽'},{key:'discount',title:'Средняя скидка',unit:'₽ / шт.'}]}),
 computed:{
 windowMonths(){return Array.from({length:24},(_,i)=>shiftMonth(this.month,i-23));},
 periodText(){return monthName(this.windowMonths[0])+' — '+monthName(this.month);},
 periodRows(){return rows.filter(r=>r.month>=this.windowMonths[0]&&r.month<=this.month);},
 filteredRows(){return this.periodRows.filter(r=>!this.category||r.category===this.category);},
 current(){return aggregate(this.filteredRows.filter(r=>r.month===this.month));},
 series(){return this.windowMonths.map(month=>({month,...aggregate(this.filteredRows.filter(r=>r.month===month))}));},
 products(){return [...d3.group(this.filteredRows,r=>r.product)].map(([id,rs])=>({...ORDER_DATA.products[id],...aggregate(rs)})).sort((a,b)=>b[this.sortKey]-a[this.sortKey]||a.name.localeCompare(b.name,'ru'));},
 categoryTotals(){return allCategories.map(name=>({name,...aggregate(this.periodRows.filter(r=>r.category===name))})).sort((a,b)=>b.spend-a.spend);}
 },
 methods:{format,monthName,color:c=>palette[allCategories.indexOf(c)%palette.length],
 draw(){this.tip=null;this.metrics.forEach(m=>smallChart(document.getElementById('trend-'+m.key),this.series,m.key,'#387c64',390,150));this.drawProducts();},
 drawProducts(){
 const target=d3.select('#product-chart');target.selectAll('*').remove();const data=this.showAll?this.products:this.products.slice(0,15),width=700,rowHeight=40;
 const svg=target.append('svg').attr('viewBox',`0 0 ${width} ${Math.max(1,data.length)*rowHeight}`).attr('role','img').attr('aria-label','Количество и сумма покупок по товарам');
 const xu=d3.scaleLinear().domain([0,d3.max(this.products,p=>p.units)||1]).range([0,112]);const xs=d3.scaleLinear().domain([0,d3.max(this.products,p=>p.spend)||1]).range([0,112]);
 const row=svg.selectAll('g.product').data(data).join('g').attr('class','product').attr('transform',(_,i)=>`translate(0,${i*rowHeight})`).attr('tabindex',0).attr('role','button').attr('aria-label',p=>`${p.name}: ${p.units} шт., ${p.spend} рублей; показать динамику цены`);
 row.append('rect').attr('width',width).attr('height',rowHeight).attr('fill',(_,i)=>i%2?'#fafbf9':'#fff');
 row.append('circle').attr('cx',12).attr('cy',18).attr('r',4).attr('fill',p=>this.color(p.category));
 row.filter(p=>PRODUCT_IMAGES[p.name]).append('image').attr('class','product-image').attr('href',p=>PRODUCT_IMAGES[p.name]).attr('x',23).attr('y',3).attr('width',32).attr('height',32);
 row.append('text').attr('class','name').attr('x',p=>PRODUCT_IMAGES[p.name]?60:26).attr('y',22).text(p=>p.name.length>42?p.name.slice(0,40)+'…':p.name);
 row.append('rect').attr('x',337).attr('y',12).attr('width',p=>xu(p.units)).attr('height',13).attr('rx',2).attr('fill',p=>this.color(p.category));
 row.append('text').attr('class','number').attr('x',493).attr('y',23).attr('text-anchor','end').text(p=>format(p.units,'orders'));
 row.append('rect').attr('x',513).attr('y',12).attr('width',p=>xs(p.spend)).attr('height',13).attr('rx',2).attr('fill',p=>this.color(p.category)).attr('opacity',.45);
 row.append('text').attr('class','number').attr('x',694).attr('y',23).attr('text-anchor','end').text(p=>format(p.spend,'spend'));
 row.on('mouseenter',(e,p)=>this.showTip(e,p)).on('click',(e,p)=>this.showTip(e,p)).on('focus',(e,p)=>this.showTip(e,p)).on('keydown',(e,p)=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();this.showTip(e,p);}});
 },
 async showTip(event,product){const rect=event.currentTarget.getBoundingClientRect(),w=Math.min(360,innerWidth-24),x=Math.min(Math.max(12,(event.clientX||rect.x)+16),innerWidth-w-12),y=Math.min(Math.max(12,rect.y-120),innerHeight-295);this.tip={product,x,y};await nextTick();const rs=this.filteredRows.filter(r=>r.product===product.id);const series=this.windowMonths.map(month=>{const ms=rs.filter(r=>r.month===month),units=sum(ms,'units');return {month,price:units?sum(ms,'spend')/units:null};});smallChart(document.getElementById('price-trend'),series,'price',this.color(product.category),320,115);}
 },
 watch:{category(){this.showAll=false;nextTick(()=>this.draw());},month(){this.showAll=false;nextTick(()=>this.draw());},sortKey(){this.tip=null;nextTick(()=>this.drawProducts());},showAll(){nextTick(()=>this.drawProducts());}},
 mounted(){this.draw();document.addEventListener('keydown',e=>{if(e.key==='Escape')this.tip=null;});}
}).mount('#app');
