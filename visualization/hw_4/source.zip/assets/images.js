// Exact product name -> relative image path. Populate with the course Items archive.
window.PRODUCT_IMAGES = {};
